import 'dart:io';

Future<void> main() async {
  if (!File('pubspec.yaml').existsSync()) {
    stderr.writeln('Run this command from the kerakart project folder.');
    exit(1);
  }
  final flutter = Platform.isWindows ? 'flutter.bat' : 'flutter';
  final process = await Process.start(
    flutter,
    [
      'create',
      '--platforms=android,web',
      '--org=com.kerakart',
      '--project-name=kerakart',
      '--no-pub',
      '.',
    ],
    mode: ProcessStartMode.inheritStdio,
    runInShell: Platform.isWindows,
  );
  final code = await process.exitCode;
  if (code != 0) exit(code);
  final generatedTest = File('test/widget_test.dart');
  if (generatedTest.existsSync()) generatedTest.deleteSync();
  final manifest = File('android/app/src/main/AndroidManifest.xml');
  if (manifest.existsSync()) {
    var text = manifest.readAsStringSync();
    text = text
        .replaceAll('android:label="kerakart"', 'android:label="Kerakart"')
        .replaceAll('@mipmap/ic_launcher', '@drawable/kerakart_icon');
    manifest.writeAsStringSync(text);
  }
  final icon = File('android/app/src/main/res/drawable/kerakart_icon.xml');
  icon.parent.createSync(recursive: true);
  icon.writeAsStringSync(
    '''<vector xmlns:android="http://schemas.android.com/apk/res/android" android:width="108dp" android:height="108dp" android:viewportWidth="108" android:viewportHeight="108">
<path android:fillColor="#106B50" android:pathData="M0,0h108v108h-108z"/>
<path android:fillColor="#FFFFFF" android:pathData="M32,27h10v24l23,-24h13l-27,28l28,26h-14l-23,-22v22h-10z"/>
</vector>''',
  );
  final web = File('web/index.html');
  if (web.existsSync()) {
    web.writeAsStringSync(
      web
          .readAsStringSync()
          .replaceAll('<title>kerakart</title>', '<title>Kerakart</title>')
          .replaceAll(
            'A new Flutter project.',
            'Kerakart — everyday, elevated.',
          ),
    );
  }
  stdout.writeln('Kerakart platforms are ready. Next: flutter pub get');
}
