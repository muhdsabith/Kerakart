import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:kerakart/data/shop_controller.dart';
import 'package:kerakart/data/shop_state.dart';
import 'package:kerakart/main.dart';
import 'package:kerakart/widgets/common.dart';
import '../tool/state_checks.dart' as checks;

void main() {
  test('Shopping rules and persisted order snapshots', checks.main);
  testWidgets('Browse, add to bag, enter address and save a demo order', (
    tester,
  ) async {
    SharedPreferences.setMockInitialValues({});
    tester.view.physicalSize = const Size(390, 844);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    final prefs = await SharedPreferences.getInstance();
    final shop = ShopController(prefs, ShopState());
    await tester.runAsync(PhotoAtlas.load);
    await tester.pumpWidget(KeraBasketApp(controller: shop));
    await tester.pumpAndSettle();
    expect(find.text('KeraBasket'), findsOneWidget);
    expect(find.byType(BrandMark), findsOneWidget);
    expect(tester.takeException(), isNull);
    await tester.scrollUntilVisible(
      find.text('Everyday cotton kurta'),
      200,
      scrollable: find.byType(Scrollable).first,
    );
    await tester.pumpAndSettle();
    expect(find.text('Everyday cotton kurta'), findsOneWidget);
    await tester.tap(find.text('Everyday cotton kurta'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('Add to bag'));
    await tester.pumpAndSettle();
    expect(shop.state.count, 1);
    await tester.pump(const Duration(seconds: 4));
    await tester.pumpAndSettle();
    await tester.tap(find.byTooltip('Shopping bag').last);
    await tester.pumpAndSettle();
    await tester.tap(find.text('Continue to checkout'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('Add delivery address'));
    await tester.pumpAndSettle();
    Future<void> enter(String label, String value) async {
      final field = find.widgetWithText(TextFormField, label);
      await tester.scrollUntilVisible(
        field,
        160,
        scrollable: find.byType(Scrollable).last,
      );
      await tester.enterText(field, value);
    }

    await enter('Full name', 'Demo Customer');
    await enter('Mobile number', '9000000000');
    await enter('House, street & area', 'Sample house');
    await enter('City / town', 'Malappuram');
    await enter('PIN code', '676505');
    await tester.scrollUntilVisible(
      find.text('Save address'),
      160,
      scrollable: find.byType(Scrollable).last,
    );
    await tester.tap(find.text('Save address'));
    await tester.pumpAndSettle();
    await tester.tap(find.widgetWithText(FilledButton, 'Review order'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('Place demo order · ₹799'));
    await tester.pumpAndSettle();
    expect(shop.state.orders.length, 1);
    expect(shop.state.bag, isEmpty);
    expect(find.text('Your demo order is saved.'), findsOneWidget);
    expect(tester.takeException(), isNull);
    final restored = await ShopController.load();
    expect(restored.state.orders.single.total, 799);
  });
  testWidgets('Small phone search and saved items work', (tester) async {
    SharedPreferences.setMockInitialValues({});
    tester.view.physicalSize = const Size(360, 800);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    final shop = ShopController(
      await SharedPreferences.getInstance(),
      ShopState(),
    );
    await tester.runAsync(PhotoAtlas.load);
    await tester.pumpWidget(KeraBasketApp(controller: shop));
    await tester.pumpAndSettle();
    expect(tester.takeException(), isNull);
    await tester.enterText(find.byType(TextField).first, 'mug');
    await tester.testTextInput.receiveAction(TextInputAction.search);
    await tester.pumpAndSettle();
    expect(find.text('Slow morning mug'), findsOneWidget);
    await tester.tap(find.byTooltip('Save item').first);
    await tester.pumpAndSettle();
    expect(shop.state.saved, contains('mug'));
    expect(tester.takeException(), isNull);
  });
  for (final textScale in [1.0, 1.5, 2.0]) {
    testWidgets('Narrow catalog fits at text scale $textScale', (tester) async {
      SharedPreferences.setMockInitialValues({});
      tester.view.physicalSize = const Size(320, 800);
      tester.view.devicePixelRatio = 1;
      tester.platformDispatcher.textScaleFactorTestValue = textScale;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);
      addTearDown(tester.platformDispatcher.clearTextScaleFactorTestValue);
      final shop = ShopController(
        await SharedPreferences.getInstance(),
        ShopState(),
      );
      await tester.runAsync(PhotoAtlas.load);
      await tester.pumpWidget(KeraBasketApp(controller: shop));
      await tester.pumpAndSettle();
      expect(tester.takeException(), isNull);
      await tester.enterText(find.byType(TextField).first, 'mug');
      await tester.testTextInput.receiveAction(TextInputAction.search);
      await tester.pumpAndSettle();
      await tester.scrollUntilVisible(
        find.text('Slow morning mug'),
        200,
        scrollable: find.byType(Scrollable).first,
      );
      await tester.pumpAndSettle();
      expect(find.text('Slow morning mug'), findsOneWidget);
      expect(tester.takeException(), isNull);
    });
  }
}
