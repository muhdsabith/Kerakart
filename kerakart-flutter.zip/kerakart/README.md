# Kerakart

A Flutter implementation of the approved warm-white and emerald shopping UI. This is an offline demo app with a working shopping flow, ready to connect to a real catalog, account system and payment backend.

## Included

- Home, categories, search, price sorting and an under-₹500 filter.
- Four curated demo products with bundled, generated product photographs.
- Product details, size selection, saved favourites and quantity controls.
- Bag totals, free demo delivery and KERA10 for a 10% demo discount.
- Address form, payment-method preview, order review and confirmation.
- Bag, saved items, address and demo order history stored on the device.
- Responsive grid and layouts for mobile, tablets and larger windows.
- Android app branding, platform generation script and GitHub APK workflow.
- No Provider dependency and no external image or font requests.

## Get an APK using only your Android phone

You do not need to extract the source ZIP for this option.

1. Create an empty GitHub repository named `kerakart` (or use your chosen repository).
2. Upload `kerakart-flutter.zip` to the repository's main page/root. Keep exactly one Kerakart source ZIP there.
3. Create a file at `.github/workflows/build-android.yml`. Paste the full contents of the separately supplied `build-android.yml` file into it, and commit.
4. Open **Actions → Build Kerakart APK → Run workflow**. A push to `main` or `master` also starts the build.
5. After the run turns green, open its **Artifacts** section and download **Kerakart-Android-APK**.
6. Extract that artifact ZIP on your phone and open `app-release.apk` to install it. Allow installation from your browser/file manager when Android asks.

If the Actions tab or upload buttons are hidden, turn on Desktop site in your phone browser. If a run fails, open the red step and share its error text.

The source ZIP is not an APK. The GitHub workflow compiles the APK. The generated Flutter Android template uses a debug signing key for its release build, suitable for personal demo installation. Configure your own persistent signing key before distributing updates or publishing to Google Play. A later build with a different signing key may require uninstalling the earlier demo, which erases its local data.

## Run with Flutter

Tested against Flutter 3.35.7 framework APIs and Dart 3.9.4 static analysis. The build workflow uses Flutter 3.35.7 and Java 17.

From the extracted `kerakart` folder:

```sh
dart tool/bootstrap.dart
flutter pub get
flutter run
```

`bootstrap.dart` uses your Flutter installation to generate standard Android and web platform folders and Gradle wrapper files. It keeps the app source and applies the Kerakart app label and green K launcher icon. The native folders are generated rather than shipping machine-specific build files.

For an APK:

```sh
flutter build apk --release
```

Output: `build/app/outputs/flutter-apk/app-release.apk`.

For a local browser preview:

```sh
flutter run -d chrome
```

Flutter's Android build documentation: https://docs.flutter.dev/deployment/android

## Checks

```sh
flutter analyze
flutter test
dart tool/state_checks.dart
```

Validation performed for this delivery:

- Dart analyzer: no issues across application, tests and setup script.
- Pure Dart shopping-state checks: passed, compiled and executed as a native executable.
- Checks cover totals, separate sizes, quantities, coupon rounding, invalid inputs, persistence, order snapshots and currency formatting.
- Full widget tests are included and are required by the GitHub workflow.
- Widget tests and APK compilation could not be run in the delivery environment because a complete Flutter runtime and Android SDK were unavailable. No APK is included or claimed as tested.

## Demo boundaries

This build does not charge money, ship products, authenticate accounts or contact a commerce server. UPI, card and cash-on-delivery are selectable previews. Checkout clearly explains this and saves a local demo order only. All prices, descriptions, ratings and product photographs are sample content. Addresses are stored on the device, not sent to a server. State is currently fixed to Kerala.

## Change the catalog and connect services

- `lib/data/catalog.dart`: demo products, sizes, prices and text.
- `lib/models/shop.dart`: product, bag, address and order models.
- `lib/data/shop_state.dart`: pure shopping calculations and order rules.
- `lib/data/shop_controller.dart`: local persistence and UI notifications.
- `lib/screens/`: home, details, bag, checkout, account and history.
- `lib/widgets/common.dart`: reusable components and product photo rendering.
- `lib/main.dart`: theme and entry point.

The product photo asset is a 2×2 atlas. The app draws one quadrant per product using Flutter's canvas, with one shared decoded image for efficient offline rendering. It is original generated imagery based on the approved concept. Replace it and the catalog with your actual merchandise before launch.

For a live shop, add a backend-backed catalog and order service, stock checks, server-validated totals, authentication and a payment provider with server-side verification. Never put payment secrets in the Flutter app. The current confirmation is deliberately labeled as a demo.
