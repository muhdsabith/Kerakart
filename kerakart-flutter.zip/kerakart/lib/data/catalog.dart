import '../models/shop.dart';

const products = <Product>[
  Product(
    id: 'kurta',
    name: 'Everyday cotton kurta',
    category: 'Fashion',
    description:
        'A little detail. A lot of comfort. An ivory kurta with delicate embroidery and an easy, relaxed fit for everyday moments.',
    material: 'Cotton • Gentle cold wash • Dry in shade',
    price: 799,
    originalPrice: 999,
    photo: 0,
    rating: 4.6,
    reviews: 128,
    sizes: ['XS', 'S', 'M', 'L', 'XL'],
  ),
  Product(
    id: 'tote',
    name: 'Everyday tote bag',
    category: 'Fashion',
    description:
        'Your day, beautifully carried. A structured tan tote with comfortable handles and space for your everyday essentials.',
    material: 'Vegan leather • Wipe clean • Tan',
    price: 599,
    originalPrice: 799,
    photo: 1,
    rating: 4.5,
    reviews: 96,
  ),
  Product(
    id: 'mug',
    name: 'Slow morning mug',
    category: 'Home',
    description:
        'Make a little room for a slower morning. A softly speckled ceramic mug with a comfortable handle and warm ivory finish.',
    material: 'Ceramic • 300 ml • Hand wash recommended',
    price: 349,
    originalPrice: 499,
    photo: 2,
    rating: 4.8,
    reviews: 64,
  ),
  Product(
    id: 'vase',
    name: 'Quiet corner vase',
    category: 'Home',
    description:
        'A sculptural ceramic vase that makes even a small corner feel considered. Style it with your favourite stems. Branches are for styling only.',
    material: 'Ceramic • Height 22 cm • Wipe with a soft cloth',
    price: 699,
    originalPrice: 899,
    photo: 3,
    rating: 4.7,
    reviews: 52,
  ),
];

Product productById(String id) => products.firstWhere((p) => p.id == id);
